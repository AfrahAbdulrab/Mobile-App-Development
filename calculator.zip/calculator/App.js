import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [result, setResult] = useState('');

  // Function to handle button presses
  const handlePress = (value) => {
    if (value === 'C') {
      setResult('');
    } else if (value === '=') {
      try {
        const processedResult = result.replace('÷', '/').replace('×', '*');
        setResult(eval(processedResult).toString());
      } catch {
        setResult('Error');
      }
    } else {
      setResult(result + value);
    }
  };

  // Button component to render calculator buttons
  const Button = ({ title }) => (
    <TouchableOpacity
      style={styles.button}
      onPress={() => handlePress(title)}
    >
      <Text style={styles.buttonText}>{title}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Display the current result */}
      <Text style={styles.resultText}>{result || '0'}</Text>

      {/* Calculator buttons arranged in rows */}
      <View style={styles.buttonContainer}>
        {['C', '+/-', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', '='].map((item) => (
          <Button key={item} title={item} />
        ))}
      </View>
    </View>
  );
}

// Styles for the calculator components
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#22252D',
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 48,
    color: '#FFFFFF',
    width: '90%',
    textAlign: 'right',
    paddingRight: 20,
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: '90%',
  },
  button: {
    backgroundColor: '#333333',
    borderRadius: 35,
    height: 80,
    width: 80,
    margin: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 24,
    color: '#FFFFFF',
  },
});
